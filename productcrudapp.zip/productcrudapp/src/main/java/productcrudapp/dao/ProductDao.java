package productcrudapp.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;


import productcrudapp.model.Product;

@Component
public class ProductDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	@Transactional
	public void createProduct(Product product)
	{	
		System.out.println(product.getPid()+" : "+product.getPname()+" : "+product.getPrice());
		hibernateTemplate.saveOrUpdate(product);
	}
	
	public List<Product> getAllProducts()
	{
		List<Product> allProds = hibernateTemplate.loadAll(Product.class);
		return allProds;
	}
	
	public Product getProduct(int pid)
	{
		Product product = hibernateTemplate.load(Product.class,pid);
		return product;
	}
	
	@Transactional
	public void updateProduct(int pid)
	{
		Product product = hibernateTemplate.get(Product.class, pid);
		hibernateTemplate.save(product);
	}
	
	@Transactional
	public void deleteProduct(int pid)
	{
		Product product = hibernateTemplate.get(Product.class, pid);
		hibernateTemplate.delete(product);
	}
}
