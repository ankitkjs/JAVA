package com.spring.orm.entities;

import java.util.List;

import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.transaction.annotation.Transactional;

public class StudentDao {
	
	private HibernateTemplate hibernateTemplate;
	
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	
	// adding a new student
	@Transactional
	public int insert(Student student)
	{
		Integer i = (Integer)hibernateTemplate.save(student);
		return i;
	}

	
	// get a single student
	//@Transactional
	public Student getStudent(int studentId)
	{
		Student s = hibernateTemplate.get(Student.class, studentId);
		return s;
	}
	
	
	// get list of all students
	//@Transactional
	public List<Student> getAllStudents()
	{
		List<Student> allStuds = hibernateTemplate.loadAll(Student.class);
		return allStuds;
	}
	
	
	// delete an existing student
	@Transactional
	public void deleteStudent(int studentId)
	{
		Student s = hibernateTemplate.load(Student.class, studentId);
		hibernateTemplate.delete(s);
	}
	
	
	// updating an existing students
	@Transactional
	public void updateStudent(Student s)
	{
		hibernateTemplate.update(s);
	}

}
