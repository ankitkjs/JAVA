package com.spring.orm;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.orm.entities.Student;
import com.spring.orm.entities.StudentDao;

public class App 
{
    public static void main( String[] args ) throws IOException
    {
        ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
        StudentDao studentDao = context.getBean("studentDao",StudentDao.class);
            
        Scanner scn = new Scanner(System.in);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        
        do
        {
        	System.out.println();
        	System.out.println();
        	System.out.println("****WELCOME TO SPRIG-ORM CRUD APP****");
        	System.out.println("press-1 to add new student");
        	System.out.println("press-2 to get data of single student");
        	System.out.println("press-3 to get data of all students");
        	System.out.println("press-4 to update an existing student");
        	System.out.println("press-5 to delete a student");
        	System.out.println("press-6 to exit");
        	System.out.println("Enter your choice: ");
        	int choice = scn.nextInt();
        	if(choice==1)
        	{
        		System.out.println("Enter Student Id:");
        		int id = scn.nextInt();
        		System.out.println("Enter Student Name:");
        		String name =  br.readLine();
        		System.out.println("Enter Student City:");
        		String city = br.readLine();
        		Student s = new Student(id,name,city);
        		studentDao.insert(s);
        		System.out.println("added a new student");
        	}
        	else if(choice==2)
        	{
        		System.out.println("Enter Student Id:");
        		int id = scn.nextInt();
        		Student stu = studentDao.getStudent(id);
        		System.out.println(stu.toString());
        	}
        	else if(choice==3)
        	{
        		List<Student> allStuds = studentDao.getAllStudents();
        		for(Student s:allStuds)
        		{
        			System.out.println(s.toString());
        		}
        	}
        	else if(choice==4)
        	{
        		System.out.println("Enter existing Student Id:");
        		int id = scn.nextInt();
        		System.out.println("Enter Student Name:");
        		String name =  br.readLine();
        		System.out.println("Enter Student City:");
        		String city = br.readLine();
        		Student s = new Student(id,name,city);
        		studentDao.updateStudent(s);
        		System.out.println("student with studentId "+ id + " updated!!");
        	}
        	else if(choice==5)
        	{
        		System.out.println("Enter existing Student Id:");
        		int id = scn.nextInt();
        		studentDao.deleteStudent(id);
        		System.out.println("student with studentId "+ id +" deleted!!");
        	}
        	else
        	{
        		System.out.println("Thank you for using...quitting!!");
        		break;
        	}  	
        }
        while(true);
        
        //((BufferedReader) context).close();
        scn.close();
    }
}
